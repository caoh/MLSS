function [TF] = tfidf(X)
[nbDoc, nbFeat] = size(X);
TF = diag(1./sum(X,2))*X;
IDF = log(nbDoc ./ (sum(logical(X),1) + 1));
for i=1:nbFeat
    TF(:,i) = TF(:,i) * IDF(i);
end
