function [c] = classify(XTrain, yTrain, XTest, h)
nbClusters = 322;

%Remove zero-columns
zeroCols = any(XTrain,1);
XTrain( :, ~zeroCols) = [];  %columns
XTrain = tfidf(XTrain);
XTest(:, ~zeroCols) = [];  %columns
XTest = tfidf(XTest);

%[IDX, clus] = kmeans(yTrain, nbClusters, 'emptyaction', 'drop');
load('/home/hong-an/Downloads/handout/code/parameters.txt', '-mat');

centroids = zeros(nbClusters, size(XTrain, 2));
for i=1:nbClusters
    centroids(i,:) = mean(XTrain(find(IDX == i), :), 1);
end

nbDoc = size(XTest, 1);

c = [];

for i = 1:nbDoc
    dist = zeros(nbClusters, 1);
    for j = 1:nbClusters
        dist(j) = sum(XTest(i,:) .* centroids(j,:)) / (norm(XTest(i,:)) * norm(centroids(j,:)));
    end
    [val, clusterid] = max(dist);
    c(i, find(C(clusterid,:) > 0)) = 1;
    i
end
